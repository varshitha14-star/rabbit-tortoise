#include <GL/glut.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

// Initial positions of the tortoise and rabbit
float tortoisePosition = -0.9f;
float rabbitPosition = -0.9f;

// Speed of the tortoise and rabbit
float tortoiseSpeed = 0.0002f;
float rabbitSpeed = 0.0005f;

// Race status
int raceStarted = 0;
int raceFinished = 0;
char winner[50];

// Function to draw the ground (road)
void drawRoad() {
    glColor3f(0.3f, 0.3f, 0.3f); // Gray color
    glBegin(GL_QUADS);
        glVertex2f(-1.0f, -0.4f);
        glVertex2f(1.0f, -0.4f);
        glVertex2f(1.0f, 0.4f);
        glVertex2f(-1.0f, 0.4f);
    glEnd();
}

// Function to draw a single tree at given coordinates
void drawTree(float x, float y) {
    glColor3f(0.55f, 0.27f, 0.07f); // Brown color for trunk
    glBegin(GL_QUADS);
        glVertex2f(x - 0.02f, y - 0.1f);
        glVertex2f(x + 0.02f, y - 0.1f);
        glVertex2f(x + 0.02f, y);
        glVertex2f(x - 0.02f, y);
    glEnd();
    glColor3f(0.0f, 0.5f, 0.0f); // Green color for leaves
    glBegin(GL_TRIANGLES);
        glVertex2f(x - 0.1f, y);
        glVertex2f(x + 0.1f, y);
        glVertex2f(x, y + 0.2f);
    glEnd();
}

// Function to draw the finish line
void drawFinishLine() {
    glColor3f(1.0f, 0.0f, 0.0f); // Red color
    glBegin(GL_QUADS);
        glVertex2f(0.9f, -0.4f);
        glVertex2f(1.0f, -0.4f);
        glVertex2f(1.0f, 0.4f);
        glVertex2f(0.9f, 0.4f);
    glEnd();
}

// Function to draw the tortoise
void drawTortoise() {
    // Body
    glColor3f(0.0f, 0.3f, 0.0f); // Dark green color for body
    glBegin(GL_POLYGON);
        glVertex2f(tortoisePosition - 0.05f, -0.35f);
        glVertex2f(tortoisePosition + 0.05f, -0.35f);
        glVertex2f(tortoisePosition + 0.07f, -0.3f);
        glVertex2f(tortoisePosition + 0.05f, -0.25f);
        glVertex2f(tortoisePosition - 0.05f, -0.25f);
        glVertex2f(tortoisePosition - 0.07f, -0.3f);
    glEnd();

    // Shell
    glColor3f(0.0f, 0.5f, 0.0f); // Lighter green for shell
    glBegin(GL_POLYGON);
        glVertex2f(tortoisePosition - 0.03f, -0.33f);
        glVertex2f(tortoisePosition + 0.03f, -0.33f);
        glVertex2f(tortoisePosition + 0.05f, -0.3f);
        glVertex2f(tortoisePosition + 0.03f, -0.27f);
        glVertex2f(tortoisePosition - 0.03f, -0.27f);
        glVertex2f(tortoisePosition - 0.05f, -0.3f);
    glEnd();

    // Shell pattern
    glColor3f(0.0f, 0.4f, 0.0f); // Medium green for shell pattern
    glBegin(GL_POLYGON);
        glVertex2f(tortoisePosition - 0.015f, -0.32f);
        glVertex2f(tortoisePosition + 0.015f, -0.32f);
        glVertex2f(tortoisePosition + 0.02f, -0.3f);
        glVertex2f(tortoisePosition + 0.015f, -0.28f);
        glVertex2f(tortoisePosition - 0.015f, -0.28f);
        glVertex2f(tortoisePosition - 0.02f, -0.3f);
    glEnd();

    // Legs
    glColor3f(0.0f, 0.3f, 0.0f); // Dark green color for legs
    glBegin(GL_QUADS);
        glVertex2f(tortoisePosition - 0.05f, -0.35f);
        glVertex2f(tortoisePosition - 0.03f, -0.35f);
        glVertex2f(tortoisePosition - 0.03f, -0.38f);
        glVertex2f(tortoisePosition - 0.05f, -0.38f);

        glVertex2f(tortoisePosition + 0.03f, -0.35f);
        glVertex2f(tortoisePosition + 0.05f, -0.35f);
        glVertex2f(tortoisePosition + 0.05f, -0.38f);
        glVertex2f(tortoisePosition + 0.03f, -0.38f);

        glVertex2f(tortoisePosition - 0.05f, -0.25f);
        glVertex2f(tortoisePosition - 0.03f, -0.25f);
        glVertex2f(tortoisePosition - 0.03f, -0.22f);
        glVertex2f(tortoisePosition - 0.05f, -0.22f);

        glVertex2f(tortoisePosition + 0.03f, -0.25f);
        glVertex2f(tortoisePosition + 0.05f, -0.25f);
        glVertex2f(tortoisePosition + 0.05f, -0.22f);
        glVertex2f(tortoisePosition + 0.03f, -0.22f);
    glEnd();

    // Head
    glColor3f(0.0f, 0.3f, 0.0f); // Dark green color for head
    glBegin(GL_POLYGON);
        glVertex2f(tortoisePosition + 0.05f, -0.3f);
        glVertex2f(tortoisePosition + 0.09f, -0.3f);
        glVertex2f(tortoisePosition + 0.09f, -0.25f);
        glVertex2f(tortoisePosition + 0.05f, -0.25f);
    glEnd();

    // Eyes
    glColor3f(1.0f, 1.0f, 1.0f); // White color for eyes
    glBegin(GL_POLYGON);
        glVertex2f(tortoisePosition + 0.06f, -0.28f);
        glVertex2f(tortoisePosition + 0.065f, -0.28f);
        glVertex2f(tortoisePosition + 0.065f, -0.27f);
        glVertex2f(tortoisePosition + 0.06f, -0.27f);
    glEnd();

    // Pupils
    glColor3f(0.0f, 0.0f, 0.0f); // Black color for pupils
    glBegin(GL_POLYGON);
        glVertex2f(tortoisePosition + 0.062f, -0.278f);
        glVertex2f(tortoisePosition + 0.064f, -0.278f);
        glVertex2f(tortoisePosition + 0.064f, -0.272f);
        glVertex2f(tortoisePosition + 0.062f, -0.272f);
    glEnd();

    // Tail
    glColor3f(0.0f, 0.3f, 0.0f); // Dark green color for tail
    glBegin(GL_POLYGON);
        glVertex2f(tortoisePosition - 0.07f, -0.33f);
        glVertex2f(tortoisePosition - 0.05f, -0.33f);
        glVertex2f(tortoisePosition - 0.06f, -0.31f);
    glEnd();
}

void drawRabbit() {
    // Body
    glColor3f(1.0f, 1.0f, 1.0f); // White color for body
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition - 0.05f, 0.05f);
        glVertex2f(rabbitPosition + 0.05f, 0.05f);
        glVertex2f(rabbitPosition + 0.05f, 0.15f);
        glVertex2f(rabbitPosition - 0.05f, 0.15f);
    glEnd();

    // Head
    glColor3f(1.0f, 1.0f, 1.0f); // White color for head
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.03f, 0.15f);
        glVertex2f(rabbitPosition + 0.09f, 0.15f);
        glVertex2f(rabbitPosition + 0.09f, 0.21f);
        glVertex2f(rabbitPosition + 0.03f, 0.21f);
    glEnd();

    // Eyes
    glColor3f(0.0f, 0.0f, 0.0f); // Black color for eyes
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.06f, 0.19f);
        glVertex2f(rabbitPosition + 0.065f, 0.19f);
        glVertex2f(rabbitPosition + 0.065f, 0.195f);
        glVertex2f(rabbitPosition + 0.06f, 0.195f);
    glEnd();

    // Pupils
    glColor3f(1.0f, 1.0f, 1.0f); // White color for pupils
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.061f, 0.192f);
        glVertex2f(rabbitPosition + 0.063f, 0.192f);
        glVertex2f(rabbitPosition + 0.063f, 0.194f);
        glVertex2f(rabbitPosition + 0.061f, 0.194f);
    glEnd();

    // Nose
    glColor3f(1.0f, 0.0f, 0.0f); // Red color for nose
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.07f, 0.18f);
        glVertex2f(rabbitPosition + 0.075f, 0.18f);
        glVertex2f(rabbitPosition + 0.0725f, 0.175f);
    glEnd();

    // Mouth
    glColor3f(1.0f, 0.5f, 0.5f); // Pink color for mouth
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.07f, 0.17f);
        glVertex2f(rabbitPosition + 0.075f, 0.17f);
        glVertex2f(rabbitPosition + 0.0725f, 0.165f);
    glEnd();

    // Ears
    glColor3f(1.0f, 1.0f, 1.0f); // White color for outer ears
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.04f, 0.21f);
        glVertex2f(rabbitPosition + 0.05f, 0.21f);
        glVertex2f(rabbitPosition + 0.045f, 0.27f);
        glVertex2f(rabbitPosition + 0.035f, 0.27f);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.07f, 0.21f);
        glVertex2f(rabbitPosition + 0.08f, 0.21f);
        glVertex2f(rabbitPosition + 0.075f, 0.27f);
        glVertex2f(rabbitPosition + 0.065f, 0.27f);
    glEnd();

    // Inner Ears
    glColor3f(1.0f, 0.8f, 0.8f); // Light pink color for inner ears
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.042f, 0.21f);
        glVertex2f(rabbitPosition + 0.048f, 0.21f);
        glVertex2f(rabbitPosition + 0.045f, 0.26f);
        glVertex2f(rabbitPosition + 0.037f, 0.26f);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition + 0.072f, 0.21f);
        glVertex2f(rabbitPosition + 0.078f, 0.21f);
        glVertex2f(rabbitPosition + 0.075f, 0.26f);
        glVertex2f(rabbitPosition + 0.067f, 0.26f);
    glEnd();

    // Tail
    glColor3f(1.0f, 1.0f, 1.0f); // White color for tail
    glBegin(GL_POLYGON);
        glVertex2f(rabbitPosition - 0.07f, 0.12f);
        glVertex2f(rabbitPosition - 0.05f, 0.12f);
        glVertex2f(rabbitPosition - 0.05f, 0.14f);
        glVertex2f(rabbitPosition - 0.07f, 0.14f);
    glEnd();

    // Legs
    glColor3f(1.0f, 1.0f, 1.0f); // White color for legs
    glBegin(GL_QUADS);
        glVertex2f(rabbitPosition - 0.05f, 0.05f);
        glVertex2f(rabbitPosition - 0.03f, 0.05f);
        glVertex2f(rabbitPosition - 0.03f, 0.02f);
        glVertex2f(rabbitPosition - 0.05f, 0.02f);

        glVertex2f(rabbitPosition + 0.03f, 0.05f);
        glVertex2f(rabbitPosition + 0.05f, 0.05f);
        glVertex2f(rabbitPosition + 0.05f, 0.02f);
        glVertex2f(rabbitPosition + 0.03f, 0.02f);

        glVertex2f(rabbitPosition - 0.05f, 0.15f);
        glVertex2f(rabbitPosition - 0.03f, 0.15f);
        glVertex2f(rabbitPosition - 0.03f, 0.18f);
        glVertex2f(rabbitPosition - 0.05f, 0.18f);

        glVertex2f(rabbitPosition + 0.03f, 0.15f);
        glVertex2f(rabbitPosition + 0.05f, 0.15f);
        glVertex2f(rabbitPosition + 0.05f, 0.18f);
        glVertex2f(rabbitPosition + 0.03f, 0.18f);
    glEnd();

    // Arms
    glColor3f(1.0f, 1.0f, 1.0f); // White color for arms
    glBegin(GL_QUADS);
        glVertex2f(rabbitPosition - 0.05f, 0.10f);
        glVertex2f(rabbitPosition - 0.03f, 0.10f);
        glVertex2f(rabbitPosition - 0.03f, 0.07f);
        glVertex2f(rabbitPosition - 0.05f, 0.07f);

        glVertex2f(rabbitPosition + 0.03f, 0.10f);
        glVertex2f(rabbitPosition + 0.05f, 0.10f);
        glVertex2f(rabbitPosition + 0.05f, 0.07f);
        glVertex2f(rabbitPosition + 0.03f, 0.07f);
    glEnd();
}



// Function to draw clouds
void drawCloud(float x, float y, float scale) {
    glColor3f(1.0f, 1.0f, 1.0f); // White color for clouds
    glBegin(GL_POLYGON);
        for (int i = 0; i < 360; i += 30) {
            float angle = i * 3.14159 / 180;
            float cloud_x = x + scale * 0.2f * cos(angle);
            float cloud_y = y + scale * 0.1f * sin(angle);
            glVertex2f(cloud_x, cloud_y);
        }
    glEnd();
}

// Function to draw grass
void drawGrass() {
    glColor3f(0.0f, 0.8f, 0.0f); // Green color for grass
    glBegin(GL_LINES);
        for (float x = -1.0f; x <= 1.0f; x += 0.02f) {
            glVertex2f(x, -0.45f); // Bottom of grass blade
            glVertex2f(x, -0.42f); // Top of grass blade
        }
    glEnd();
}

// Function to display text on screen
void displayText(float x, float y, const char *string) {
    glColor3f(1.0f, 1.0f, 1.0f); // White color for text
    glRasterPos2f(x, y);
    int len = (int) strlen(string);
    for (int i = 0; i < len; i++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, string[i]);
    }
}

// Function to draw the scene
void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Draw scenery
    drawRoad();
    drawFinishLine();

    // Draw trees at specified positions
    float treePositions[] = {-0.8f, -0.5f, -0.2f, 0.1f, 0.4f, 0.7f};
    for (int i = 0; i < 6; ++i) {
        drawTree(treePositions[i], 0.5f);
    }

    // Draw clouds at specified positions and scales
    drawCloud(-0.5f, 0.8f, 0.2f);
    drawCloud(0.0f, 0.9f, 0.25f);
    drawCloud(0.7f, 0.7f, 0.3f);

    // Additional clouds
    drawCloud(-0.2f, 0.75f, 0.15f);
    drawCloud(-0.7f, 0.85f, 0.18f);

    // Display dialogue between Tortoise and Rabbit above them
    if (!raceStarted) {
        displayText(tortoisePosition - 0.1f, -0.2f, "Tortoise: Hey Rabbit, ready for another race?");
        displayText(rabbitPosition - 0.1f, 0.25f, "Rabbit: Ha! You're on, Tortoise! Let's see who wins this time.");
    }

    drawTortoise();
    drawRabbit();

    // Draw grass animation
    drawGrass();

    // Display winner
    if (raceFinished) {
        displayText(-0.1f, 0.8f, winner);
    }

    glutSwapBuffers();
}


// Function to update the positions of the tortoise and rabbit
void update(int value) {
    if (raceStarted && !raceFinished) {
        tortoisePosition += tortoiseSpeed;
        rabbitPosition += rabbitSpeed;

        // Check if rabbit has reached finish line
        if (rabbitPosition >= 0.9f) {
            raceFinished = 1;
            strcpy(winner, "Rabbit wins!");
        }

        // Check if tortoise has reached finish line
        if (tortoisePosition >= 0.9f && !raceFinished) {
            raceFinished = 1;
            strcpy(winner, "Tortoise wins!");
        }
    }

    glutPostRedisplay();
    glutTimerFunc(10, update, 0);
}

// Function to handle key presses
void handleKeypress(unsigned char key, int x, int y) {
    switch (key) {
        case ' ':
            raceStarted = 1;
            break;
        case 27: // Escape key
            exit(0);
            break;
    }
}

// Function to initialize OpenGL
void init() {
    glClearColor(0.529f, 0.808f, 0.922f, 1.0f); // Light blue background
    gluOrtho2D(-1.0, 1.0, -0.5, 0.5);
}

// Main function
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Tortoise and Rabbit Race");
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(handleKeypress);
    glutTimerFunc(10, update, 0);
    glutMainLoop();
    return 0;
}
